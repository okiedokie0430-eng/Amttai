import admin from 'firebase-admin';
import { Client, Databases, Query } from 'node-appwrite';

const INVALID_TOKEN_CODES = new Set([
  'messaging/invalid-registration-token',
  'messaging/registration-token-not-registered'
]);

function parseJsonBody(raw) {
  if (!raw) {
    return {};
  }

  if (typeof raw === 'object') {
    return raw;
  }

  if (typeof raw !== 'string') {
    throw new Error('Invalid JSON body.');
  }

  if (!raw.trim()) {
    return {};
  }

  try {
    return JSON.parse(raw);
  } catch {
    throw new Error('Invalid JSON body.');
  }
}

function parseServiceAccount() {
  const inline = process.env.FIREBASE_SERVICE_ACCOUNT_JSON || '';
  if (inline.trim()) {
    return JSON.parse(inline);
  }

  const base64 = process.env.FIREBASE_SERVICE_ACCOUNT_BASE64 || '';
  if (base64.trim()) {
    const decoded = Buffer.from(base64, 'base64').toString('utf8');
    return JSON.parse(decoded);
  }

  throw new Error(
    'Missing Firebase credentials. Set FIREBASE_SERVICE_ACCOUNT_JSON or FIREBASE_SERVICE_ACCOUNT_BASE64.'
  );
}

function chunkArray(items, size) {
  const chunks = [];
  for (let index = 0; index < items.length; index += size) {
    chunks.push(items.slice(index, index + size));
  }
  return chunks;
}

function toFlatStringMap(data) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) {
    return {};
  }

  const result = {};
  for (const [key, value] of Object.entries(data)) {
    if (!key) continue;
    if (value === null || value === undefined) continue;
    result[key] = String(value);
  }
  return result;
}

function extractTokens(value) {
  if (!Array.isArray(value)) {
    return [];
  }

  return value
    .map((item) => String(item || '').trim())
    .filter((item) => item.length > 0);
}

function initFirebase() {
  if (admin.apps.length > 0) {
    return;
  }

  const serviceAccount = parseServiceAccount();
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
  });
}

async function listAllUsersWithTokens(databases, options) {
  const docs = [];
  const limit = 100;
  let offset = 0;

  while (true) {
    const result = await databases.listDocuments(options.databaseId, options.usersCollectionId, [
      Query.limit(limit),
      Query.offset(offset)
    ]);

    if (!result.documents.length) {
      break;
    }

    docs.push(...result.documents);
    offset += result.documents.length;

    if (result.documents.length < limit) {
      break;
    }
  }

  const ownerMap = new Map();
  const tokenMapByUser = new Map();

  for (const doc of docs) {
    const userId = doc.$id;
    const pushTokens = extractTokens(doc[options.pushTokensField]);
    tokenMapByUser.set(userId, pushTokens);

    for (const token of pushTokens) {
      if (!ownerMap.has(token)) {
        ownerMap.set(token, new Set());
      }
      ownerMap.get(token).add(userId);
    }
  }

  return {
    userDocs: docs,
    tokenOwners: ownerMap,
    tokenMapByUser
  };
}

async function pruneInvalidTokens(databases, options, staleTokens, tokenOwners, tokenMapByUser, log) {
  if (!staleTokens.size) {
    return 0;
  }

  let updatedUsers = 0;
  const usersToUpdate = new Map();

  for (const token of staleTokens) {
    const owners = tokenOwners.get(token);
    if (!owners) continue;

    for (const userId of owners) {
      if (!usersToUpdate.has(userId)) {
        usersToUpdate.set(userId, new Set(tokenMapByUser.get(userId) || []));
      }
      usersToUpdate.get(userId).delete(token);
    }
  }

  for (const [userId, tokenSet] of usersToUpdate.entries()) {
    const sanitized = Array.from(tokenSet);
    await databases.updateDocument(options.databaseId, options.usersCollectionId, userId, {
      [options.pushTokensField]: sanitized
    });
    updatedUsers += 1;
  }

  log(`Pruned ${staleTokens.size} invalid token(s) from ${updatedUsers} user document(s).`);
  return updatedUsers;
}

export default async ({ req, res, log, error }) => {
  try {
    const payload = parseJsonBody(req.body || '{}');
    const title = String(payload.title || '').trim();
    const body = String(payload.body || '').trim();
    const data = toFlatStringMap(payload.data);

    if (!title || !body) {
      return res.json({ ok: false, message: 'title and body are required.' }, 400);
    }

    const sharedSecret = String(process.env.BROADCAST_PUSH_SECRET || '').trim();
    if (sharedSecret) {
      const incomingSecret = String(payload.secret || '').trim();
      if (incomingSecret !== sharedSecret) {
        return res.json({ ok: false, message: 'Unauthorized broadcast request.' }, 403);
      }
    }

    const endpoint = process.env.APPWRITE_ENDPOINT;
    const projectId = process.env.APPWRITE_PROJECT_ID;
    const apiKey = process.env.APPWRITE_API_KEY;

    if (!endpoint || !projectId || !apiKey) {
      return res.json(
        {
          ok: false,
          message:
            'Missing Appwrite env vars. Required: APPWRITE_ENDPOINT, APPWRITE_PROJECT_ID, APPWRITE_API_KEY.'
        },
        500
      );
    }

    const options = {
      databaseId: process.env.DATABASE_ID || 'amttai_db',
      usersCollectionId: process.env.USERS_COLLECTION_ID || 'users',
      pushTokensField: process.env.USERS_PUSH_TOKENS_FIELD || 'push_tokens'
    };

    const client = new Client().setEndpoint(endpoint).setProject(projectId).setKey(apiKey);
    const databases = new Databases(client);

    initFirebase();

    const { tokenOwners, tokenMapByUser } = await listAllUsersWithTokens(databases, options);
    const allTokens = Array.from(tokenOwners.keys());

    if (allTokens.length === 0) {
      return res.json({
        ok: true,
        message: 'No push tokens found. Broadcast skipped.',
        stats: {
          usersWithTokens: 0,
          totalTokens: 0,
          sent: 0,
          failed: 0,
          prunedUsers: 0
        }
      });
    }

    const staleTokens = new Set();
    let sentCount = 0;
    let failedCount = 0;

    for (const batch of chunkArray(allTokens, 500)) {
      const response = await admin.messaging().sendEachForMulticast({
        tokens: batch,
        notification: { title, body },
        data,
        android: {
          priority: 'high'
        },
        apns: {
          headers: {
            'apns-priority': '10'
          }
        }
      });

      sentCount += response.successCount;
      failedCount += response.failureCount;

      response.responses.forEach((item, index) => {
        if (item.success || !item.error) return;
        const code = item.error.code || '';
        if (INVALID_TOKEN_CODES.has(code)) {
          staleTokens.add(batch[index]);
        }
      });
    }

    const prunedUsers = await pruneInvalidTokens(
      databases,
      options,
      staleTokens,
      tokenOwners,
      tokenMapByUser,
      log
    );

    return res.json({
      ok: true,
      message: 'Broadcast sent.',
      stats: {
        usersWithTokens: tokenMapByUser.size,
        totalTokens: allTokens.length,
        sent: sentCount,
        failed: failedCount,
        prunedUsers
      }
    });
  } catch (err) {
    error(String(err?.stack || err));
    return res.json(
      {
        ok: false,
        message: err instanceof Error ? err.message : 'Broadcast failed.'
      },
      500
    );
  }
};
